package project;

public interface Printable {

    public static final double VAT = 0.15;

    public abstract void print();

}
